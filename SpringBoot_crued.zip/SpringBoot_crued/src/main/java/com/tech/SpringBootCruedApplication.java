package com.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCruedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCruedApplication.class, args);
		
		System.out.println("jay shree ram");
		
		
		
		
		
	}

}
